// Backend/Controllers/BulkUploadController.cs
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ShopForHomeBackend.Services;
using System.Threading.Tasks;

namespace ShopForHomeBackend.Controllers
{
    [Authorize(Roles = "Admin")]
    [Route("api/[controller]")]
    [ApiController]
    public class BulkUploadController : ControllerBase
    {
        private readonly IBulkUploadService _bulkUploadService;

        public BulkUploadController(IBulkUploadService bulkUploadService)
        {
            _bulkUploadService = bulkUploadService;
        }

        [HttpPost("products")]
        public async Task<IActionResult> UploadProductsCsv([FromForm] IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest("No file uploaded.");

            var result = await _bulkUploadService.UploadProductsFromCsvAsync(file);

            if (!result.IsSuccess)
                return BadRequest(result.Message);

            return Ok(new { Message = "Products uploaded successfully.", CreatedCount = result.CreatedCount });
        }
    }
}
