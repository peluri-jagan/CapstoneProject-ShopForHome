// Backend/DTOs/CartDto.cs
namespace ShopForHomeBackend.DTOs
{
    public class CartDto
    {
        public int ProductId { get; set; }
        public int Quantity { get; set; }
    }
}
