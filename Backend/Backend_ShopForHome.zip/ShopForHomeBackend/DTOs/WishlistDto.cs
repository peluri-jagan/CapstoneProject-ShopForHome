// Backend/DTOs/WishlistDto.cs
namespace ShopForHomeBackend.DTOs
{
    public class WishlistDto
    {
        public int ProductId { get; set; }
    }
}
