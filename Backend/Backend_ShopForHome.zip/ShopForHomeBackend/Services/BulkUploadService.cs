// Backend/Services/BulkUploadService.cs
using CsvHelper;
using Microsoft.AspNetCore.Http;
using ShopForHomeBackend.Data;
using ShopForHomeBackend.Models;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ShopForHomeBackend.Services
{
    public class BulkUploadService : IBulkUploadService
    {
        private readonly AppDbContext _context;

        public BulkUploadService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<(bool IsSuccess, string Message, int CreatedCount)> UploadProductsFromCsvAsync(IFormFile file)
        {
            try
            {
                using var stream = file.OpenReadStream();
                using var reader = new StreamReader(stream);
                using var csv = new CsvReader(reader, CultureInfo.InvariantCulture);

                var records = csv.GetRecords<ProductCsvRecord>().ToList();

                foreach (var record in records)
                {
                    var product = new Product
                    {
                        Name = record.Name,
                        Description = record.Description,
                        Price = record.Price,
                        StockQuantity = record.StockQuantity,
                        Rating = record.Rating,
                        ImageUrl = record.ImageUrl,
                        CategoryId = record.CategoryId
                    };
                    _context.Products.Add(product);
                }
                var count = await _context.SaveChangesAsync();

                return (true, "Upload successful", count);
            }
            catch (System.Exception ex)
            {
                return (false, ex.Message, 0);
            }
        }
    }

    // CSV record mapping class
    public class ProductCsvRecord
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public int StockQuantity { get; set; }
        public double Rating { get; set; }
        public string ImageUrl { get; set; }
        public int CategoryId { get; set; }
    }
}
