// Models/UploadProductCsvRequest.cs
using Microsoft.AspNetCore.Http;

namespace ShopForHomeBackend.Models
{
    public class UploadProductCsvRequest
    {
        public IFormFile File { get; set; }
    }
}
