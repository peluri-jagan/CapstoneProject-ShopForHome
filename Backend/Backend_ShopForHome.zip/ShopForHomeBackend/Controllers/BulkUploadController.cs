using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ShopForHomeBackend.Models;
using ShopForHomeBackend.Services;
using System.Threading.Tasks;

namespace ShopForHomeBackend.Controllers
{
    [Authorize(Roles = "Admin")]
    [Route("api/[controller]")]
    [ApiController]
    public class BulkUploadController : ControllerBase
    {
        private readonly IBulkUploadService _bulkUploadService;

        public BulkUploadController(IBulkUploadService bulkUploadService)
        {
            _bulkUploadService = bulkUploadService;
        }

        [HttpPost("products")]
        [Consumes("multipart/form-data")]
        public async Task<IActionResult> UploadProductsCsv([FromForm] UploadProductCsvRequest request)
        {
            if (request.File == null || request.File.Length == 0)
                return BadRequest("No file uploaded.");

            var result = await _bulkUploadService.UploadProductsFromCsvAsync(request.File);

            if (!result.IsSuccess)
                return BadRequest(result.Message);

            return Ok(new { Message = "Products uploaded successfully.", CreatedCount = result.CreatedCount });
        }
    }
}
